package com.example.myrecyclerview.model;

import com.example.myrecyclerview.R;

import java.util.ArrayList;

public class PlacesData {
    private static String[] placesName = {
            "Taman Nasional Sabangau",
            "Jembatan Kahayan",
            "Taman Wisata Alam Bukit Tangkiling",
            "Museum Balanga",
            "Sungai Batu Sei Gohong",
            "Taman & Kuliner Kumkum",
            "Taman Pasuk Kameloh",
            "Wisata Susur Sungai Kahayan",
            "Penangkaran Orang Utan Nyaru Menteng",
            "Rumah Betang",
            "Danum Bahandang",
            "Sei Gohong",
            "Bukit Banama",
            "Wisata Matan Andau",
            "Manasa ArgoWisata",
            "Bukit Cinta",
    };

    private static String[] placesDetail = {
            "Merupakan kawasan konservasi dengan luas areanya mencapai 568.700 hektare. Taman nasional ini menjadi habitat bagi berbagai jenis flora dan fauna, seperti orangutan, bekantan, dan burung enggang. Kamu bisa wisata alam dengan menyusuri sungai di dalam hutan gambut, mengamati satwa liar, hingga mengunjungi pusat rehabilitasi orangutan. Cocok bagi kamu yang suka petualangan dan ingin menikmati keindahan alam Indonesia. ",
            "Adalah jembatan yang melintasi Sungai Kahayan di Kota Palangkaraya, Kalimantan Tengah. Sebagai informasi, jembatan ini memiliki panjang 1.082 meter dan lebar 22 meter, serta memiliki empat pilar yang menjulang tinggi. Jembatan ini merupakan jembatan terpanjang di Kalimantan dan salah satu ikon Kota Palangkaraya. Selain sebagai sarana penghubung transportasi, jembatan ini juga terkenal sebagai objek wisata yang menarik. Dari atas jembatan, Anda dapat menikmati pemandangan Sungai Kahayan yang indah dan megah, serta hutan bakau yang hijau di sekitarnya. Jembatan ini juga menjadi tempat favorit untuk menyaksikan matahari terbit dan terbenam, serta menangkap ikan di bawahnya. Pada malam hari, pemandangannya akan semakin cantik karena ada tambahan lampu warna-warni yang menghiasinya." ,
            "Tempat wisata dengan aktivitas petualangan yang tak kalah menarik yaitu Taman Wisata Alam Bukit Tangkiling Palangkaraya. Lokasinya berada di Desa Bukit Rawi, Kecamatan Bukit Batu, Kabupaten Pulang Pisau, sekitar 34 km dari Kota Palangkaraya. Taman ini menawarkan pemandangan alam yang indah dan asri, dengan hutan tropis, bukit-bukit, danau, sungai, serta berbagai flora dan fauna khas Kalimantan. Salah satu daya tarik utama taman ini yaitu Bukit Tangkiling, sebuah bukit setinggi 256 meter yang merupakan titik tertinggi di sekitar Palangkaraya. Dari atas bukit ini, Anda dapat menikmati panorama kota, hutan, dan sungai Kahayan yang membelah Palangkaraya. Selain itu, taman ini juga menyediakan fasilitas seperti camping ground, flying fox, outbond, trekking, dan wisata kuliner.",
            "Tempat wisata sejarah dan budaya yang tak kalah menari yaitu Museum Balanga yang terletak di Jalan Tjilik Riwut No.Km. 2.5, Palangka, Kec. Jekan Raya, Kota Palangka Raya, Kalimantan Tengah. Museum ini menyimpan berbagai koleksi benda-benda peninggalan masa lalu, seperti alat-alat pertanian, peralatan rumah tangga, senjata tradisional, pakaian adat, dan kerajinan tangan dari berbagai suku di Kalimantan Tengah. Selain itu di dalamnya terdapat replika rumah betang, yaitu rumah panggung khas suku Dayak yang berfungsi sebagai tempat tinggal bersama dan pusat kegiatan sosial budaya. Museum Balanga Palangkaraya merupakan salah satu destinasi wisata edukatif yang menarik untuk dikunjungi, karena dapat memberikan wawasan dan pengalaman baru tentang sejarah dan kebudayaan Kalimantan Tengah.",
            "Buat Anda yang suka dengan petualangan bisa mengunjungi Sungai Batu di Sei Gohong, Kec. Bukit Batu, Kota Palangka Raya, Kalimantan Tengah. Tempat wisata alam Palangkaraya ini menawarkan pemandangan alam yang indah dan asri, dengan hutan bakau, pohon-pohon besar, dan berbagai jenis satwa liar yang hidup di sekitarnya. Salah satu daya tarik utama dari Sungai Batu Sei Gohong yaitu susur sungai dengan menggunakan ban seperti di Cikadongdong River Tubing. Selain itu, Anda juga dapat menikmati aktivitas lain seperti berenang, memancing, berkemah, atau bersantai di pinggir sungai. Destinasi ini merupakan salah satu tempat yang cocok untuk menghabiskan waktu bersama keluarga atau teman-teman sambil menikmati keindahan alam Kalimantan.",
            "Untuk pilihan wisata kulinernya, salah satu rekomendasi terbaik yaitu Taman & Kuliner Kumkum di Jl. Wisata No.1, Pahandut Seberang, Kec. Pahandut, Kota Palangka Raya, Kalimantan Tengah. Tempat ini menawarkan berbagai fasilitas rekreasi dan kuliner yang bisa Anda nikmati. Di sini, Anda dapat berjalan-jalan di taman yang asri dan indah, bermain di area bermain anak-anak, atau bersantai di gazebo-gazebo yang tersedia. Anda juga dapat menikmati aneka makanan khas daerah di Indonesia khususnya Palangkaraya, seperti soto banjar, nasi kuning, ayam bakar, dan lain-lain. Jika ingin mengunjunginya, tempat ini buka setiap hari dari pukul 08.00 hingga 17.00 WIB. Harga tiket masuknya sangat terjangkau, yaitu Rp 5.000 per orang.",
            "Taman Pasuk Kameloh Palangkaraya adalah salah satu destinasi wisata alam yang menarik di ibu kota Kalimantan Tengah. Lokasinya berada di Jalan S. Parman, Langkai, Kec. Pahandut, Kota Palangka Raya, Kalimantan Tengah. Anda bisa datang dengan transportasi umum atau taksi online. Namun jika ingin leluasa explorasi Kota Palangakaraya lebih dalam, bisa menyewa mobil di Salsa Wisata. Harga sewa mobil hariannya murah dan pilihan armadanya bermacam-macam. Untuk menarik para wisatawan, Taman ini menawarkan pemandangan indah danau buatan yang dikelilingi oleh pepohonan hijau dan bunga-bunga warna-warni. Selain itu, taman ini juga dilengkapi dengan fasilitas seperti gazebo, jogging track, permainan anak-anak, dan tempat makan. Jadi di sini Anda bisa bermain sekaligus berwisata kuliner. Taman ini cocok untuk dikunjungi oleh semua kalangan, baik keluarga, pasangan, maupun teman-teman. Taman ini bisa menjadi tempat yang menyenangkan untuk bersantai, berolahraga, berfoto, atau sekadar menikmati keindahan alam.",
            "Selain tempat bersantai masyarakat kota Palangkaraya, di Dermaga Rambang ini banyak sekali kedai-kedai yang menyajikan kuliner khas Kalimantan Tengah.  Dan kali ini, kami mengajak anda mencoba menjelajahi sungai Kahayan, dengan menaiki kapal susur sungai ini. Untuk jam operasional keberangkatan kapal susur sungai Kahayan ini, berangkat pada pukul 16:00 Waktu Indonesia Bagian Barat atau sore hari. Dengan tarif biaya Rp. 25.000 per orang untuk sekali berlayar dengan fasilitas lengkap di dalam kapal. Rute perjalanan susur sungai ini yang menjadi daya tarik wisatawan dalam kota maupun luar kota Palangkaraya. Kapal akan melewati salah satu ikonik kebanggaan kota Palangkaraya yaitu salah satunya Jembatan Kahayan yang berada di atas Daerah Aliran Sungai Kahayan.  Selain dimanjakan dengan pemandangan indah bersama keluarga, teman dan pasangan, kita juga akan disuguhi dengan aktivitas warga yang menaiki transportasi air yakni klotok atau getek dan pemukiman warga yakni rumah lanting atau disebut juga rumah terapung yang merupakan salah satu arsitektur tradisional yang ada dipinggiran sungai kahayan.",
            "Masih di sekitaran danau tahai, Anda bisa menikmati objek wisata lainnya lo. Anda bisa mengunjungi penangkaran orang utan nyaru menteng. Penangkaran ini berada di bawah kepemilikan yayasan borneo orangutan. Wisata yang satu ini sangat cocok bagi anak anak agar tertarik sekaligus belajar mengenai kehidupan orang utan. Selama di penangkaran, Anda bisa melihat bagaimana kehidupan orang utan di habitat aslinya yang masih sangat terjaga. Tak hanya itu, Anda juga bisa melakukan interaksi dengan hewan tersebut. pengalaman berkunjung ke penangkaran orang utan nyaru menteng tentu akan menjadi pengalaman yang akan sulit Anda lupakan. Terutama bagi anak-anak yang jarang menjumpai orang utan di alam bebas seperti yang ada di penangkaran orang utan nyaru menteng.",
            "Wisata sejarah tidak kalah menarik dikunjungi. Pernyataan ini dapat dibuktikan ketika Anda mengunjungi Rumah Adat Betang Palangkaraya. Disini wisatawan diajak untuk merasakan suasana zaman dahulu lewat sebuah rumah megah yang didirikan oleh suku Dayak asli. Rumah adat tersebut dibangun khusus bagi keluarga besar dari pimpinan mereka. Rumah peninggalan sejara ini memiliki panjang kurang lebih 30 hingga 150 meter, serta lebar sekitar 10 hingga 30 meter. Gaya arsiteknya yang cukup unik, merupakan daya tarik lainnya dari destinasi wisata satu ini. Selain menikmati kemegahan rumah adat, para wisatawan bahkan tertarik mengabadikan bangunan tersebut sebagai kenang kenangan.",
            "Danum Bahandang ialah wisata eksotik yang berlokasi di Bukit Batu tepatnya di KM 38 Kanarakan. Menjadi objek wisata yang mengusung konsep Eco-tourism dengan suasana yang berbeda, tentunya memiliki daya tarik tersendiri bagi siapa saja yang berkunjung. Wisata ini salah satu destinasi wisata alternatif untuk seru-seruan bersama teman-teman, di sini ada beberapa kegiatan yang dapat dilakukan oleh pengunjung seperti Camping Ground, Outbound, River Tubing dan Program Adopsi Pohon.",
            "Desa Wisata Sei Gohong merupakan sebuah desa yang menjadi salah satu tujuan wisata yang cukup populer di Kota Palangka Raya, dari pusat kota hanya berjarak sekitar 35 Km dengan menempuh jalur darat kita langsung bisa mengunjungi destinasi wisata yang satu ini dengan hanya menghabiskan waktu sekitar 20 menit perjalanan. Sei Gohong adalah salah satu kelurahan dikecamatan bukit batu, kota Palangka Raya, Kalimantan Tengah, Indonesia. Kelurahan ini memiliki potensi lokal yang dapat digali dan dikembangkan untuk menarik minat para wisatawan yakni kondisi desa yang masih alami,memiliki Sungai Batu dan Sungai Rungan yang dapat dijadikan objek wisata, memiliki bangunan-bangunan adat dayak dan terdapat budidaya komoditas bawang dayak. Daerah Aliran Sungai (DAS) mirip arena arung jeram versi mini, pengunjung dapat menyusuri aliran sungai dengan ban bekas yang disewakan. Pepohonan yang tumbuh disekitar anak sungai ini juga unik, karena pepohonan ini tumbuh di atas batu.",
            "Tempat wisata ini adalah tempat dimana kita dapat menemukan sebuah batu yang berbentuk menyerupai sebuah perahu dan berbagai batu-batu megah berjejer. Selain dari itu batu banama juga memberikan rasa tenang dan indah melalu pemandangan-pemandangan yang di berikan oleh alam itu sendiri dan mendapatkan udara yang bersih dan alami. Saat ini batu banama menjadi ramai di kunjungi oleh para pemburu keindahan alam. Batu banama selain alamnya yang sangat indah dan keren, lokasi Bukit Banama berpotensi dikembangkan menjadi lokasi wisata religius. Di kawasan Batu Banama juga terdapat Pura kecil yang di lengkapi dengan pemandangan patung-patung khas yang mengelilingi pura tersebut. Pura ini di jadikan sebagai sarana ibadah umat hindu. Panorama Alam yang indah ini dikategorikan sebagai wisata yang mengandung relegius, karena pada lokasi areal wisata ini terdapat Pura Agung Sali Paseban/Satya Dharma. Disamping itu legenda mengenai terjadinya batu banama itu sendiri yang dilihat dari samping mirip seperti sebuah bahtera yang terdampar dikelilingi pura tersebut.",
            "Matan Andau merupakan salah satu destinasi wisata alam yang menarik di sekitar Kota Palangkaraya, Kalimantan Tengah, Indonesia. Daerah ini terkenal dengan keindahan alamnya, termasuk sungai, hutan, dan kehidupan satwa liar. Di Matan Andau, kamu bisa menikmati kegiatan seperti trekking atau hiking melalui hutan yang subur, mengeksplorasi keanekaragaman flora dan fauna, serta menikmati pemandangan alam yang memukau. Terdapat juga sungai di sekitar area ini yang bisa dinikmati untuk kegiatan seperti berperahu atau menyusuri sungai. Selain kegiatan alam, biasanya terdapat juga kegiatan budaya dan tradisional masyarakat setempat yang bisa diikuti atau diamati, seperti pertunjukan tari atau musik tradisional.",
            "Argo Wisata adalah salah satu destinasi wisata yang populer di Kota Palangkaraya, Kalimantan Tengah, Indonesia. Tempat ini menawarkan pengalaman yang menarik dengan berbagai atraksi dan kegiatan yang dapat dinikmati pengunjung. Di Argo Wisata, kamu bisa menemukan berbagai wahana dan aktivitas, seperti taman bermain untuk anak-anak, kolam renang, permainan air, serta area piknik yang nyaman untuk bersantai bersama keluarga atau teman-teman. Selain itu, terdapat juga spot-spot menarik untuk berfoto dan menikmati pemandangan. Bagi yang suka aktivitas olahraga, terdapat fasilitas untuk bersepeda atau jogging di sekitar area Argo Wisata. Ada juga area kuliner dan tempat berbelanja untuk memenuhi kebutuhan selama berkunjung. Selain itu, Argo Wisata sering menjadi tempat untuk acara atau festival tertentu yang diadakan di Kota Palangkaraya. Jadi, saat berkunjung, pastikan untuk mengecek acara atau kegiatan apa yang sedang berlangsung di sana. Argo Wisata bisa menjadi pilihan yang baik untuk menghabiskan waktu santai atau bersenang-senang di Kota Palangkaraya, terutama bagi keluarga atau grup yang ingin menikmati berbagai aktivitas rekreasi dalam satu tempat.",
            "Bukit Cinta (Love Hill) merupakan salah satu tempat wisata yang terkenal di Palangkaraya, Kalimantan Tengah, Indonesia. Tempat ini populer karena pemandangannya yang indah dan menjadi destinasi romantis bagi pasangan karena legenda yang terkait dengan namanya. Bukit Cinta menawarkan pemandangan yang spektakuler dari ketinggian, terutama saat matahari terbenam. Beberapa pengunjung datang ke sini untuk menikmati keindahan alam, mengabadikan momen romantis, atau hanya sekadar menikmati suasana tenang di tengah alam. Selain menikmati pemandangan, di Bukit Cinta juga terdapat area-area yang nyaman untuk bersantai, berfoto, atau piknik. Pengunjung seringkali menghabiskan waktu di sini untuk menikmati udara segar, memotret momen-momen indah, atau hanya sekadar menikmati keindahan alam sekitarnya."
    };

    private static int[] placesPhoto = {
            R.drawable.taman_nasional_sabangau,
            R.drawable.jembatan_kahayan,
            R.drawable.tangkiling,
            R.drawable.museum,
            R.drawable.sei_gohong,
            R.drawable.kumkum,
            R.drawable.pasuk_kameloh,
            R.drawable.susur_sungai,
            R.drawable.orang_utan,
            R.drawable.rumah_betang,
            R.drawable.danum_bahandang,
            R.drawable.sei_gohong,
            R.drawable.bukit_banama,
            R.drawable.matan_andau,
            R.drawable.argowisata,
            R.drawable.bukit_cinta
    };

    public static ArrayList<Place> getListData() {
        ArrayList<Place> list = new ArrayList<>();
        for (int i = 0; i < placesName.length; i++) {
            Place place = new Place();
            place.setName(placesName[i]);
            place.setDetail(placesDetail[i]);
            place.setPhoto(placesPhoto[i]);
            list.add(place);
        }
        return list;
    }

    public Place getData(int id) {
        Place place = new Place();
        place.setName(placesName[id]);
        place.setDetail(placesDetail[id]);
        place.setPhoto(placesPhoto[id]);
        return place;
    }
}
